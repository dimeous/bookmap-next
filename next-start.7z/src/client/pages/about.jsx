import React from 'react';

import Layout from '~/layouts/main';

export default () => (
  <Layout>
    <div>
      <h2>This is about page</h2>
    </div>
  </Layout>
);
