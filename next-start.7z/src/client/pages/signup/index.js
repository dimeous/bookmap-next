import Signup from './signup';

export default Signup;
