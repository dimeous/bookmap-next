import PrivacyPolicy from './privacy-policy';

export default PrivacyPolicy;
