import ResetPassword from './reset-password';

export default ResetPassword;
