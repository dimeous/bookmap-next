import Terms from './terms';

export default Terms;
