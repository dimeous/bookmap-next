import PrivacyLayout from './privacy';

export default PrivacyLayout;
