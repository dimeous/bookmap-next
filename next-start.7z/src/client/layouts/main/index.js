import MainLayout from './main';

export default MainLayout;
