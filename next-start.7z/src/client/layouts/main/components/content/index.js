import Content from './content';

export default Content;
