import HeaderContent from './header-content';

export default HeaderContent;
