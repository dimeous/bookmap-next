import Auth from './auth';

export default Auth;
