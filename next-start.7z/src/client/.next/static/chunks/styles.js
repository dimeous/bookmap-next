(window["webpackJsonp_N_E"] = window["webpackJsonp_N_E"] || []).push([["styles"],{

/***/ "./components/background/background.styles.pcss":
/*!******************************************************!*\
  !*** ./components/background/background.styles.pcss ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin
/* harmony default export */ __webpack_exports__["default"] = ({"background":"background_3r-il","purple":"purple_2_DzG","blue":"blue_1xxGO","green":"green_1806T"});
    if(true) {
      // 1608880847429
      var cssReload = __webpack_require__(/*! D:/work/react/bookmap/next/node_modules/mini-css-extract-plugin/dist/hmr/hotModuleReplacement.js */ "../../node_modules/mini-css-extract-plugin/dist/hmr/hotModuleReplacement.js")(module.i, {"locals":true});
      module.hot.dispose(cssReload);
      
    }
  

/***/ }),

/***/ "./components/button-link/button-link.styles.pcss":
/*!********************************************************!*\
  !*** ./components/button-link/button-link.styles.pcss ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin
/* harmony default export */ __webpack_exports__["default"] = ({"button":"button_1xKw8","link":"link_2PAtL","medium":"medium_1VcAs","small":"small_3neg7"});
    if(true) {
      // 1608880847263
      var cssReload = __webpack_require__(/*! D:/work/react/bookmap/next/node_modules/mini-css-extract-plugin/dist/hmr/hotModuleReplacement.js */ "../../node_modules/mini-css-extract-plugin/dist/hmr/hotModuleReplacement.js")(module.i, {"locals":true});
      module.hot.dispose(cssReload);
      
    }
  

/***/ }),

/***/ "./components/button/button.styles.pcss":
/*!**********************************************!*\
  !*** ./components/button/button.styles.pcss ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin
/* harmony default export */ __webpack_exports__["default"] = ({"button":"button_3q8_p","loading":"loading_3Ab0u","Gradient":"Gradient_3FBM6","gradient":"Gradient_3FBM6","purple":"purple_2deuD","green":"green_FrwWI","blue":"blue_UI2ig","medium":"medium_2Ydf2","small":"small_2X7W8"});
    if(true) {
      // 1608880847254
      var cssReload = __webpack_require__(/*! D:/work/react/bookmap/next/node_modules/mini-css-extract-plugin/dist/hmr/hotModuleReplacement.js */ "../../node_modules/mini-css-extract-plugin/dist/hmr/hotModuleReplacement.js")(module.i, {"locals":true});
      module.hot.dispose(cssReload);
      
    }
  

/***/ }),

/***/ "./layouts/main/components/content/content.styles.pcss":
/*!*************************************************************!*\
  !*** ./layouts/main/components/content/content.styles.pcss ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin
/* harmony default export */ __webpack_exports__["default"] = ({"content":"content_1bZLQ"});
    if(true) {
      // 1608880847418
      var cssReload = __webpack_require__(/*! D:/work/react/bookmap/next/node_modules/mini-css-extract-plugin/dist/hmr/hotModuleReplacement.js */ "../../node_modules/mini-css-extract-plugin/dist/hmr/hotModuleReplacement.js")(module.i, {"locals":true});
      module.hot.dispose(cssReload);
      
    }
  

/***/ }),

/***/ "./layouts/main/components/footer/footer.styles.pcss":
/*!***********************************************************!*\
  !*** ./layouts/main/components/footer/footer.styles.pcss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin
/* harmony default export */ __webpack_exports__["default"] = ({"wrap":"wrap_3jfM2","purple":"purple_20su5","green":"green_2K-rj","blue":"blue_3xrS5","footer":"footer_DwIlK","link":"link_1fRj_"});
    if(true) {
      // 1608880847410
      var cssReload = __webpack_require__(/*! D:/work/react/bookmap/next/node_modules/mini-css-extract-plugin/dist/hmr/hotModuleReplacement.js */ "../../node_modules/mini-css-extract-plugin/dist/hmr/hotModuleReplacement.js")(module.i, {"locals":true});
      module.hot.dispose(cssReload);
      
    }
  

/***/ }),

/***/ "./layouts/main/components/header-content/header-content.styles.pcss":
/*!***************************************************************************!*\
  !*** ./layouts/main/components/header-content/header-content.styles.pcss ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin
/* harmony default export */ __webpack_exports__["default"] = ({"header-content":"header-content_27wtZ","headerContent":"header-content_27wtZ"});
    if(true) {
      // 1608880846970
      var cssReload = __webpack_require__(/*! D:/work/react/bookmap/next/node_modules/mini-css-extract-plugin/dist/hmr/hotModuleReplacement.js */ "../../node_modules/mini-css-extract-plugin/dist/hmr/hotModuleReplacement.js")(module.i, {"locals":true});
      module.hot.dispose(cssReload);
      
    }
  

/***/ }),

/***/ "./layouts/main/components/header/components/arrow/arrow.styles.pcss":
/*!***************************************************************************!*\
  !*** ./layouts/main/components/header/components/arrow/arrow.styles.pcss ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin
/* harmony default export */ __webpack_exports__["default"] = ({"arrow":"arrow_2BnhL"});
    if(true) {
      // 1608880847298
      var cssReload = __webpack_require__(/*! D:/work/react/bookmap/next/node_modules/mini-css-extract-plugin/dist/hmr/hotModuleReplacement.js */ "../../node_modules/mini-css-extract-plugin/dist/hmr/hotModuleReplacement.js")(module.i, {"locals":true});
      module.hot.dispose(cssReload);
      
    }
  

/***/ }),

/***/ "./layouts/main/components/header/header.styles.pcss":
/*!***********************************************************!*\
  !*** ./layouts/main/components/header/header.styles.pcss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin
/* harmony default export */ __webpack_exports__["default"] = ({"nav":"nav_2MKMy","menu":"menu_2wvbv","item":"item_3vjgb","logo":"logo_10nU0","links":"links_1BRln","link":"link_1m5wc","login":"login_2dqOy","text":"text_3wl-5","arrow":"arrow_3sRVA","container":"container_3Ttjv"});
    if(true) {
      // 1608880847587
      var cssReload = __webpack_require__(/*! D:/work/react/bookmap/next/node_modules/mini-css-extract-plugin/dist/hmr/hotModuleReplacement.js */ "../../node_modules/mini-css-extract-plugin/dist/hmr/hotModuleReplacement.js")(module.i, {"locals":true});
      module.hot.dispose(cssReload);
      
    }
  

/***/ }),

/***/ "./layouts/main/main.styles.pcss":
/*!***************************************!*\
  !*** ./layouts/main/main.styles.pcss ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin
/* harmony default export */ __webpack_exports__["default"] = ({"hello_motor":"hello_motor_38mi2","helloMotor":"hello_motor_38mi2","wrap":"wrap_IN5Zs"});
    if(true) {
      // 1608880847391
      var cssReload = __webpack_require__(/*! D:/work/react/bookmap/next/node_modules/mini-css-extract-plugin/dist/hmr/hotModuleReplacement.js */ "../../node_modules/mini-css-extract-plugin/dist/hmr/hotModuleReplacement.js")(module.i, {"locals":true});
      module.hot.dispose(cssReload);
      
    }
  

/***/ }),

/***/ "./pages/main/main.styles.pcss":
/*!*************************************!*\
  !*** ./pages/main/main.styles.pcss ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin
/* harmony default export */ __webpack_exports__["default"] = ({"layout":"layout_36fe4","icons":"icons_1JpIK","page":"page_2D2Lv","intro":"intro_1oYsQ","title":"title_12L7x","description":"description_3IxQw","logo":"logo_1OR2I","container":"container_37iYq","link":"link_11640","content":"content_35gaC","ship-description":"ship-description_7q_2J","shipDescription":"ship-description_7q_2J"});
    if(true) {
      // 1608880847200
      var cssReload = __webpack_require__(/*! D:/work/react/bookmap/next/node_modules/mini-css-extract-plugin/dist/hmr/hotModuleReplacement.js */ "../../node_modules/mini-css-extract-plugin/dist/hmr/hotModuleReplacement.js")(module.i, {"locals":true});
      module.hot.dispose(cssReload);
      
    }
  

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9iYWNrZ3JvdW5kL2JhY2tncm91bmQuc3R5bGVzLnBjc3M/MDNkMiIsIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9idXR0b24tbGluay9idXR0b24tbGluay5zdHlsZXMucGNzcz8yZjkyIiwid2VicGFjazovL19OX0UvLi9jb21wb25lbnRzL2J1dHRvbi9idXR0b24uc3R5bGVzLnBjc3M/YmM4OSIsIndlYnBhY2s6Ly9fTl9FLy4vbGF5b3V0cy9tYWluL2NvbXBvbmVudHMvY29udGVudC9jb250ZW50LnN0eWxlcy5wY3NzPzExZTYiLCJ3ZWJwYWNrOi8vX05fRS8uL2xheW91dHMvbWFpbi9jb21wb25lbnRzL2Zvb3Rlci9mb290ZXIuc3R5bGVzLnBjc3M/ZTUxNCIsIndlYnBhY2s6Ly9fTl9FLy4vbGF5b3V0cy9tYWluL2NvbXBvbmVudHMvaGVhZGVyLWNvbnRlbnQvaGVhZGVyLWNvbnRlbnQuc3R5bGVzLnBjc3M/OTliZCIsIndlYnBhY2s6Ly9fTl9FLy4vbGF5b3V0cy9tYWluL2NvbXBvbmVudHMvaGVhZGVyL2NvbXBvbmVudHMvYXJyb3cvYXJyb3cuc3R5bGVzLnBjc3M/NjgwNSIsIndlYnBhY2s6Ly9fTl9FLy4vbGF5b3V0cy9tYWluL2NvbXBvbmVudHMvaGVhZGVyL2hlYWRlci5zdHlsZXMucGNzcz8yZTJlIiwid2VicGFjazovL19OX0UvLi9sYXlvdXRzL21haW4vbWFpbi5zdHlsZXMucGNzcz8yY2ZjIiwid2VicGFjazovL19OX0UvLi9wYWdlcy9tYWluL21haW4uc3R5bGVzLnBjc3M/ODQ5ZiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQUE7QUFBQTtBQUNlLGdFQUFDLGtHQUFrRyxFQUFDO0FBQ25ILE9BQU8sSUFBVTtBQUNqQjtBQUNBLHNCQUFzQixtQkFBTyxDQUFDLHFMQUFrRyxFQUFFLFFBQVMsR0FBRyxjQUFjO0FBQzVKOztBQUVBOzs7Ozs7Ozs7Ozs7O0FDUEE7QUFBQTtBQUNlLGdFQUFDLDBGQUEwRixFQUFDO0FBQzNHLE9BQU8sSUFBVTtBQUNqQjtBQUNBLHNCQUFzQixtQkFBTyxDQUFDLHFMQUFrRyxFQUFFLFFBQVMsR0FBRyxjQUFjO0FBQzVKOztBQUVBOzs7Ozs7Ozs7Ozs7O0FDUEE7QUFBQTtBQUNlLGdFQUFDLDBOQUEwTixFQUFDO0FBQzNPLE9BQU8sSUFBVTtBQUNqQjtBQUNBLHNCQUFzQixtQkFBTyxDQUFDLHFMQUFrRyxFQUFFLFFBQVMsR0FBRyxjQUFjO0FBQzVKOztBQUVBOzs7Ozs7Ozs7Ozs7O0FDUEE7QUFBQTtBQUNlLGdFQUFDLDBCQUEwQixFQUFDO0FBQzNDLE9BQU8sSUFBVTtBQUNqQjtBQUNBLHNCQUFzQixtQkFBTyxDQUFDLHFMQUFrRyxFQUFFLFFBQVMsR0FBRyxjQUFjO0FBQzVKOztBQUVBOzs7Ozs7Ozs7Ozs7O0FDUEE7QUFBQTtBQUNlLGdFQUFDLGtJQUFrSSxFQUFDO0FBQ25KLE9BQU8sSUFBVTtBQUNqQjtBQUNBLHNCQUFzQixtQkFBTyxDQUFDLHFMQUFrRyxFQUFFLFFBQVMsR0FBRyxjQUFjO0FBQzVKOztBQUVBOzs7Ozs7Ozs7Ozs7O0FDUEE7QUFBQTtBQUNlLGdFQUFDLCtFQUErRSxFQUFDO0FBQ2hHLE9BQU8sSUFBVTtBQUNqQjtBQUNBLHNCQUFzQixtQkFBTyxDQUFDLHFMQUFrRyxFQUFFLFFBQVMsR0FBRyxjQUFjO0FBQzVKOztBQUVBOzs7Ozs7Ozs7Ozs7O0FDUEE7QUFBQTtBQUNlLGdFQUFDLHNCQUFzQixFQUFDO0FBQ3ZDLE9BQU8sSUFBVTtBQUNqQjtBQUNBLHNCQUFzQixtQkFBTyxDQUFDLHFMQUFrRyxFQUFFLFFBQVMsR0FBRyxjQUFjO0FBQzVKOztBQUVBOzs7Ozs7Ozs7Ozs7O0FDUEE7QUFBQTtBQUNlLGdFQUFDLHNOQUFzTixFQUFDO0FBQ3ZPLE9BQU8sSUFBVTtBQUNqQjtBQUNBLHNCQUFzQixtQkFBTyxDQUFDLHFMQUFrRyxFQUFFLFFBQVMsR0FBRyxjQUFjO0FBQzVKOztBQUVBOzs7Ozs7Ozs7Ozs7O0FDUEE7QUFBQTtBQUNlLGdFQUFDLHVGQUF1RixFQUFDO0FBQ3hHLE9BQU8sSUFBVTtBQUNqQjtBQUNBLHNCQUFzQixtQkFBTyxDQUFDLHFMQUFrRyxFQUFFLFFBQVMsR0FBRyxjQUFjO0FBQzVKOztBQUVBOzs7Ozs7Ozs7Ozs7O0FDUEE7QUFBQTtBQUNlLGdFQUFDLHVVQUF1VSxFQUFDO0FBQ3hWLE9BQU8sSUFBVTtBQUNqQjtBQUNBLHNCQUFzQixtQkFBTyxDQUFDLHFMQUFrRyxFQUFFLFFBQVMsR0FBRyxjQUFjO0FBQzVKOztBQUVBIiwiZmlsZSI6InN0YXRpYy9jaHVua3Mvc3R5bGVzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gZXh0cmFjdGVkIGJ5IG1pbmktY3NzLWV4dHJhY3QtcGx1Z2luXG5leHBvcnQgZGVmYXVsdCB7XCJiYWNrZ3JvdW5kXCI6XCJiYWNrZ3JvdW5kXzNyLWlsXCIsXCJwdXJwbGVcIjpcInB1cnBsZV8yX0R6R1wiLFwiYmx1ZVwiOlwiYmx1ZV8xeHhHT1wiLFwiZ3JlZW5cIjpcImdyZWVuXzE4MDZUXCJ9O1xuICAgIGlmKG1vZHVsZS5ob3QpIHtcbiAgICAgIC8vIDE2MDg4ODA4NDc0MjlcbiAgICAgIHZhciBjc3NSZWxvYWQgPSByZXF1aXJlKFwiRDovd29yay9yZWFjdC9ib29rbWFwL25leHQvbm9kZV9tb2R1bGVzL21pbmktY3NzLWV4dHJhY3QtcGx1Z2luL2Rpc3QvaG1yL2hvdE1vZHVsZVJlcGxhY2VtZW50LmpzXCIpKG1vZHVsZS5pZCwge1wibG9jYWxzXCI6dHJ1ZX0pO1xuICAgICAgbW9kdWxlLmhvdC5kaXNwb3NlKGNzc1JlbG9hZCk7XG4gICAgICBcbiAgICB9XG4gICIsIi8vIGV4dHJhY3RlZCBieSBtaW5pLWNzcy1leHRyYWN0LXBsdWdpblxuZXhwb3J0IGRlZmF1bHQge1wiYnV0dG9uXCI6XCJidXR0b25fMXhLdzhcIixcImxpbmtcIjpcImxpbmtfMlBBdExcIixcIm1lZGl1bVwiOlwibWVkaXVtXzFWY0FzXCIsXCJzbWFsbFwiOlwic21hbGxfM25lZzdcIn07XG4gICAgaWYobW9kdWxlLmhvdCkge1xuICAgICAgLy8gMTYwODg4MDg0NzI2M1xuICAgICAgdmFyIGNzc1JlbG9hZCA9IHJlcXVpcmUoXCJEOi93b3JrL3JlYWN0L2Jvb2ttYXAvbmV4dC9ub2RlX21vZHVsZXMvbWluaS1jc3MtZXh0cmFjdC1wbHVnaW4vZGlzdC9obXIvaG90TW9kdWxlUmVwbGFjZW1lbnQuanNcIikobW9kdWxlLmlkLCB7XCJsb2NhbHNcIjp0cnVlfSk7XG4gICAgICBtb2R1bGUuaG90LmRpc3Bvc2UoY3NzUmVsb2FkKTtcbiAgICAgIFxuICAgIH1cbiAgIiwiLy8gZXh0cmFjdGVkIGJ5IG1pbmktY3NzLWV4dHJhY3QtcGx1Z2luXG5leHBvcnQgZGVmYXVsdCB7XCJidXR0b25cIjpcImJ1dHRvbl8zcThfcFwiLFwibG9hZGluZ1wiOlwibG9hZGluZ18zQWIwdVwiLFwiR3JhZGllbnRcIjpcIkdyYWRpZW50XzNGQk02XCIsXCJncmFkaWVudFwiOlwiR3JhZGllbnRfM0ZCTTZcIixcInB1cnBsZVwiOlwicHVycGxlXzJkZXVEXCIsXCJncmVlblwiOlwiZ3JlZW5fRnJ3V0lcIixcImJsdWVcIjpcImJsdWVfVUkyaWdcIixcIm1lZGl1bVwiOlwibWVkaXVtXzJZZGYyXCIsXCJzbWFsbFwiOlwic21hbGxfMlg3VzhcIn07XG4gICAgaWYobW9kdWxlLmhvdCkge1xuICAgICAgLy8gMTYwODg4MDg0NzI1NFxuICAgICAgdmFyIGNzc1JlbG9hZCA9IHJlcXVpcmUoXCJEOi93b3JrL3JlYWN0L2Jvb2ttYXAvbmV4dC9ub2RlX21vZHVsZXMvbWluaS1jc3MtZXh0cmFjdC1wbHVnaW4vZGlzdC9obXIvaG90TW9kdWxlUmVwbGFjZW1lbnQuanNcIikobW9kdWxlLmlkLCB7XCJsb2NhbHNcIjp0cnVlfSk7XG4gICAgICBtb2R1bGUuaG90LmRpc3Bvc2UoY3NzUmVsb2FkKTtcbiAgICAgIFxuICAgIH1cbiAgIiwiLy8gZXh0cmFjdGVkIGJ5IG1pbmktY3NzLWV4dHJhY3QtcGx1Z2luXG5leHBvcnQgZGVmYXVsdCB7XCJjb250ZW50XCI6XCJjb250ZW50XzFiWkxRXCJ9O1xuICAgIGlmKG1vZHVsZS5ob3QpIHtcbiAgICAgIC8vIDE2MDg4ODA4NDc0MThcbiAgICAgIHZhciBjc3NSZWxvYWQgPSByZXF1aXJlKFwiRDovd29yay9yZWFjdC9ib29rbWFwL25leHQvbm9kZV9tb2R1bGVzL21pbmktY3NzLWV4dHJhY3QtcGx1Z2luL2Rpc3QvaG1yL2hvdE1vZHVsZVJlcGxhY2VtZW50LmpzXCIpKG1vZHVsZS5pZCwge1wibG9jYWxzXCI6dHJ1ZX0pO1xuICAgICAgbW9kdWxlLmhvdC5kaXNwb3NlKGNzc1JlbG9hZCk7XG4gICAgICBcbiAgICB9XG4gICIsIi8vIGV4dHJhY3RlZCBieSBtaW5pLWNzcy1leHRyYWN0LXBsdWdpblxuZXhwb3J0IGRlZmF1bHQge1wid3JhcFwiOlwid3JhcF8zamZNMlwiLFwicHVycGxlXCI6XCJwdXJwbGVfMjBzdTVcIixcImdyZWVuXCI6XCJncmVlbl8ySy1yalwiLFwiYmx1ZVwiOlwiYmx1ZV8zeHJTNVwiLFwiZm9vdGVyXCI6XCJmb290ZXJfRHdJbEtcIixcImxpbmtcIjpcImxpbmtfMWZSal9cIn07XG4gICAgaWYobW9kdWxlLmhvdCkge1xuICAgICAgLy8gMTYwODg4MDg0NzQxMFxuICAgICAgdmFyIGNzc1JlbG9hZCA9IHJlcXVpcmUoXCJEOi93b3JrL3JlYWN0L2Jvb2ttYXAvbmV4dC9ub2RlX21vZHVsZXMvbWluaS1jc3MtZXh0cmFjdC1wbHVnaW4vZGlzdC9obXIvaG90TW9kdWxlUmVwbGFjZW1lbnQuanNcIikobW9kdWxlLmlkLCB7XCJsb2NhbHNcIjp0cnVlfSk7XG4gICAgICBtb2R1bGUuaG90LmRpc3Bvc2UoY3NzUmVsb2FkKTtcbiAgICAgIFxuICAgIH1cbiAgIiwiLy8gZXh0cmFjdGVkIGJ5IG1pbmktY3NzLWV4dHJhY3QtcGx1Z2luXG5leHBvcnQgZGVmYXVsdCB7XCJoZWFkZXItY29udGVudFwiOlwiaGVhZGVyLWNvbnRlbnRfMjd3dFpcIixcImhlYWRlckNvbnRlbnRcIjpcImhlYWRlci1jb250ZW50XzI3d3RaXCJ9O1xuICAgIGlmKG1vZHVsZS5ob3QpIHtcbiAgICAgIC8vIDE2MDg4ODA4NDY5NzBcbiAgICAgIHZhciBjc3NSZWxvYWQgPSByZXF1aXJlKFwiRDovd29yay9yZWFjdC9ib29rbWFwL25leHQvbm9kZV9tb2R1bGVzL21pbmktY3NzLWV4dHJhY3QtcGx1Z2luL2Rpc3QvaG1yL2hvdE1vZHVsZVJlcGxhY2VtZW50LmpzXCIpKG1vZHVsZS5pZCwge1wibG9jYWxzXCI6dHJ1ZX0pO1xuICAgICAgbW9kdWxlLmhvdC5kaXNwb3NlKGNzc1JlbG9hZCk7XG4gICAgICBcbiAgICB9XG4gICIsIi8vIGV4dHJhY3RlZCBieSBtaW5pLWNzcy1leHRyYWN0LXBsdWdpblxuZXhwb3J0IGRlZmF1bHQge1wiYXJyb3dcIjpcImFycm93XzJCbmhMXCJ9O1xuICAgIGlmKG1vZHVsZS5ob3QpIHtcbiAgICAgIC8vIDE2MDg4ODA4NDcyOThcbiAgICAgIHZhciBjc3NSZWxvYWQgPSByZXF1aXJlKFwiRDovd29yay9yZWFjdC9ib29rbWFwL25leHQvbm9kZV9tb2R1bGVzL21pbmktY3NzLWV4dHJhY3QtcGx1Z2luL2Rpc3QvaG1yL2hvdE1vZHVsZVJlcGxhY2VtZW50LmpzXCIpKG1vZHVsZS5pZCwge1wibG9jYWxzXCI6dHJ1ZX0pO1xuICAgICAgbW9kdWxlLmhvdC5kaXNwb3NlKGNzc1JlbG9hZCk7XG4gICAgICBcbiAgICB9XG4gICIsIi8vIGV4dHJhY3RlZCBieSBtaW5pLWNzcy1leHRyYWN0LXBsdWdpblxuZXhwb3J0IGRlZmF1bHQge1wibmF2XCI6XCJuYXZfMk1LTXlcIixcIm1lbnVcIjpcIm1lbnVfMnd2YnZcIixcIml0ZW1cIjpcIml0ZW1fM3ZqZ2JcIixcImxvZ29cIjpcImxvZ29fMTBuVTBcIixcImxpbmtzXCI6XCJsaW5rc18xQlJsblwiLFwibGlua1wiOlwibGlua18xbTV3Y1wiLFwibG9naW5cIjpcImxvZ2luXzJkcU95XCIsXCJ0ZXh0XCI6XCJ0ZXh0XzN3bC01XCIsXCJhcnJvd1wiOlwiYXJyb3dfM3NSVkFcIixcImNvbnRhaW5lclwiOlwiY29udGFpbmVyXzNUdGp2XCJ9O1xuICAgIGlmKG1vZHVsZS5ob3QpIHtcbiAgICAgIC8vIDE2MDg4ODA4NDc1ODdcbiAgICAgIHZhciBjc3NSZWxvYWQgPSByZXF1aXJlKFwiRDovd29yay9yZWFjdC9ib29rbWFwL25leHQvbm9kZV9tb2R1bGVzL21pbmktY3NzLWV4dHJhY3QtcGx1Z2luL2Rpc3QvaG1yL2hvdE1vZHVsZVJlcGxhY2VtZW50LmpzXCIpKG1vZHVsZS5pZCwge1wibG9jYWxzXCI6dHJ1ZX0pO1xuICAgICAgbW9kdWxlLmhvdC5kaXNwb3NlKGNzc1JlbG9hZCk7XG4gICAgICBcbiAgICB9XG4gICIsIi8vIGV4dHJhY3RlZCBieSBtaW5pLWNzcy1leHRyYWN0LXBsdWdpblxuZXhwb3J0IGRlZmF1bHQge1wiaGVsbG9fbW90b3JcIjpcImhlbGxvX21vdG9yXzM4bWkyXCIsXCJoZWxsb01vdG9yXCI6XCJoZWxsb19tb3Rvcl8zOG1pMlwiLFwid3JhcFwiOlwid3JhcF9JTjVac1wifTtcbiAgICBpZihtb2R1bGUuaG90KSB7XG4gICAgICAvLyAxNjA4ODgwODQ3MzkxXG4gICAgICB2YXIgY3NzUmVsb2FkID0gcmVxdWlyZShcIkQ6L3dvcmsvcmVhY3QvYm9va21hcC9uZXh0L25vZGVfbW9kdWxlcy9taW5pLWNzcy1leHRyYWN0LXBsdWdpbi9kaXN0L2htci9ob3RNb2R1bGVSZXBsYWNlbWVudC5qc1wiKShtb2R1bGUuaWQsIHtcImxvY2Fsc1wiOnRydWV9KTtcbiAgICAgIG1vZHVsZS5ob3QuZGlzcG9zZShjc3NSZWxvYWQpO1xuICAgICAgXG4gICAgfVxuICAiLCIvLyBleHRyYWN0ZWQgYnkgbWluaS1jc3MtZXh0cmFjdC1wbHVnaW5cbmV4cG9ydCBkZWZhdWx0IHtcImxheW91dFwiOlwibGF5b3V0XzM2ZmU0XCIsXCJpY29uc1wiOlwiaWNvbnNfMUpwSUtcIixcInBhZ2VcIjpcInBhZ2VfMkQyTHZcIixcImludHJvXCI6XCJpbnRyb18xb1lzUVwiLFwidGl0bGVcIjpcInRpdGxlXzEyTDd4XCIsXCJkZXNjcmlwdGlvblwiOlwiZGVzY3JpcHRpb25fM0l4UXdcIixcImxvZ29cIjpcImxvZ29fMU9SMklcIixcImNvbnRhaW5lclwiOlwiY29udGFpbmVyXzM3aVlxXCIsXCJsaW5rXCI6XCJsaW5rXzExNjQwXCIsXCJjb250ZW50XCI6XCJjb250ZW50XzM1Z2FDXCIsXCJzaGlwLWRlc2NyaXB0aW9uXCI6XCJzaGlwLWRlc2NyaXB0aW9uXzdxXzJKXCIsXCJzaGlwRGVzY3JpcHRpb25cIjpcInNoaXAtZGVzY3JpcHRpb25fN3FfMkpcIn07XG4gICAgaWYobW9kdWxlLmhvdCkge1xuICAgICAgLy8gMTYwODg4MDg0NzIwMFxuICAgICAgdmFyIGNzc1JlbG9hZCA9IHJlcXVpcmUoXCJEOi93b3JrL3JlYWN0L2Jvb2ttYXAvbmV4dC9ub2RlX21vZHVsZXMvbWluaS1jc3MtZXh0cmFjdC1wbHVnaW4vZGlzdC9obXIvaG90TW9kdWxlUmVwbGFjZW1lbnQuanNcIikobW9kdWxlLmlkLCB7XCJsb2NhbHNcIjp0cnVlfSk7XG4gICAgICBtb2R1bGUuaG90LmRpc3Bvc2UoY3NzUmVsb2FkKTtcbiAgICAgIFxuICAgIH1cbiAgIl0sInNvdXJjZVJvb3QiOiIifQ==