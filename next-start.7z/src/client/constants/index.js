export const states = {
  purple: 'purple',
  green: 'green',
  blue: 'blue',
};
