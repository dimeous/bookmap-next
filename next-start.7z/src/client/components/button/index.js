import Button, { sizes } from './button';

export default Button;
export { sizes };
