import SignUpGoogle from './signup-google';

export default SignUpGoogle;
