const config = require('./src/server/config/next.config');

module.exports = config;
